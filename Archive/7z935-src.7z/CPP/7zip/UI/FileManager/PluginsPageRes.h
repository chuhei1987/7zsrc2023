#define IDD_PLUGINS          999
#define IDT_PLUGINS_PLUGINS  999
#define IDL_PLUGINS          999
#define IDB_PLUGINS_OPTIONS  999
