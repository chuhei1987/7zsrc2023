#define MY_VER_MAJOR 9
#define MY_VER_MINOR 35
#define MY_VER_BUILD 00
#define MY_VERSION "9.35 beta"
// #define MY_7ZIP_VERSION "9.35"
#define MY_DATE "2014-12-07"
#undef MY_COPYRIGHT
#undef MY_VERSION_COPYRIGHT_DATE
#define MY_COPYRIGHT ": Igor Pavlov : Public domain"
#define MY_VERSION_COPYRIGHT_DATE MY_VERSION " " MY_COPYRIGHT " : " MY_DATE
