// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

// #define _WIN32_WINNT 0x0400
#define _WIN32_WINNT 0x0500
#define WINVER _WIN32_WINNT

#include "../../../Common/Common.h"

#include <ShlObj.h>

#endif
