// Windows/Console.cpp

#include "StdAfx.h"

#include "Windows/Console.h"

namespace NWindows{
namespace NConsole{

}}
