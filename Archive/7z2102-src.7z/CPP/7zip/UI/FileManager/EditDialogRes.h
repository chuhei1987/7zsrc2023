#define IDD_EDIT_DLG  94
#define IDE_EDIT 100
