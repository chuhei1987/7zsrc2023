// ClassDefs.cpp

#include "StdAfx.h"

#include "../../../Common/MyWindows.h"

#include "../../../Common/MyInitGuid.h"

#include "../Agent/Agent.h"

#include "MyWindowsNew.h"
