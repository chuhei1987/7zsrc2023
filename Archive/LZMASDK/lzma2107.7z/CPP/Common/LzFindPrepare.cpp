// Sha256Prepare.cpp

#include "StdAfx.h"

#include "../../C/LzFind.h"

static struct CLzFindPrepare { CLzFindPrepare() { LzFindPrepare(); } } g_CLzFindPrepare;
