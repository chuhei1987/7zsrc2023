// 7zFolderOutStream.cpp

#include "StdAfx.h"
