// SortUtils.h

#ifndef ZIP7_INC_SORT_UTLS_H
#define ZIP7_INC_SORT_UTLS_H

#include "../../../Common/MyString.h"

void SortFileNames(const UStringVector &strings, CUIntVector &indices);

#endif
