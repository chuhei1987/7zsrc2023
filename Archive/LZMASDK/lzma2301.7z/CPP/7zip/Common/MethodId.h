// MethodId.h

#ifndef ZIP7_INC_7Z_METHOD_ID_H
#define ZIP7_INC_7Z_METHOD_ID_H

#include "../../Common/MyTypes.h"

typedef UInt64 CMethodId;

#endif
