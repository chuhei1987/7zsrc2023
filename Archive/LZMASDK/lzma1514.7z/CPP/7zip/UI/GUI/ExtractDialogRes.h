#define IDD_EXTRACT     3400
#define IDD_EXTRACT_2  13400

#define IDC_EXTRACT_PATH             100
#define IDB_EXTRACT_SET_PATH         101
#define IDC_EXTRACT_PATH_MODE        102
#define IDC_EXTRACT_OVERWRITE_MODE   103

#define IDE_EXTRACT_PASSWORD         120

#define IDE_EXTRACT_NAME             130
#define IDX_EXTRACT_NAME_ENABLE      131


#define IDT_EXTRACT_EXTRACT_TO      3401
#define IDT_EXTRACT_PATH_MODE       3410
#define IDT_EXTRACT_OVERWRITE_MODE  3420

#define IDX_EXTRACT_ELIM_DUP        3430
#define IDX_EXTRACT_NT_SECUR        3431
// #define IDX_EXTRACT_ALT_STREAMS     3432

#define IDX_PASSWORD_SHOW           3803
#define IDG_PASSWORD                3807
